<form action="<?php echo base_url('Menu/editpengumuman/' . $pengumuman->id_pengumuman); ?>" method="post">
    <div class="modal-body">

        <div class="form-group">
            <input type="text" class="form-control" id="nama_pengumuman" name="nama_pengumuman" placeholder="nama pengumuman" value="<?php echo $pengumuman->nama_pengumuman; ?>">
            <?= form_error('nama_pengumuman', '<small class="text-danger">', '</small>') ?>
        </div>
        <div class="form-group">
            <textarea type="textarea" class="form-control" id="deskripsi" name="deskripsi" placeholder="deskripsi"><?php echo $pengumuman->deskripsi; ?></textarea>
            <?= form_error('deskripsi', '<small class="text-danger">', '</small>') ?>
        </div>



    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">tutup</button>
        <button type="submit" class="btn btn-primary">edit</button>
    </div>
</form>