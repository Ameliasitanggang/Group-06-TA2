<form action="<?= base_url('Menu/TambahPengumuman'); ?>" method="post">
    <div class="modal-body">

        <div class="form-group">
            <input type="text" class="form-control" id="nama_pengumuman" name="nama_pengumuman" placeholder="nama pengumuman">
        </div>
        <div class="form-group">
            <textarea type="textarea" class="form-control" id="deskripsi" name="deskripsi" placeholder="deskripsi"></textarea>
        </div>

        <div class="custom-file">
            <input type="file" class="custom-file-input" id="file_pengumuman" name="file_pengumuman">
            <label class="custom-file-label" for="image">pilih file</label>
        </div>


    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">tutup</button>
        <button type="submit" class="btn btn-primary">tambah</button>
    </div>
</form>