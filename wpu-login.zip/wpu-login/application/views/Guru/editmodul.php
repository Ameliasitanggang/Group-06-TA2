<form action="<?php echo base_url('Guru/editmodul/' . $modul->id_modul); ?>" method="post">
    <div class="modal-body">

        <div class="form-group">
            <input type="text" class="form-control" id="nama_modul" name="nama_modul" placeholder="nama modul" value="<?php echo $modul->nama_modul; ?>">
            <?= form_error('nama_modul', '<small class="text-danger">', '</small>') ?>
        </div>
        <div class="form-group">
            <textarea type="textarea" class="form-control" id="Deskripsi_modul" name="Deskripsi_modul" placeholder="deskripsi"><?php echo $modul->Deskripsi_modul; ?></textarea>
            <?= form_error('Deskripsi_modul', '<small class="text-danger">', '</small>') ?>
        </div>
        <div class="form-group">
            <input type="file" class="form-control" id="file_modul" name="file_modul" value="<?php echo $modul->file_modul; ?>">
            <?= form_error('file_modul', '<small class="text-danger">', '</small>') ?>
        </div>




    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">tutup</button>
        <button type="submit" class="btn btn-primary">edit</button>
    </div>
</form>