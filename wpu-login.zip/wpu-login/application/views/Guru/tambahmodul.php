<form action="<?= base_url('Guru/tambahmodul'); ?>" method="post">
    <div class="modal-body">

        <div class="form-group">
            <input type="text" class="form-control" id="nama_modul" name="nama_modul" placeholder="Nama Modul">
        </div>
        <div class="form-group">
            <textarea type="textarea" class="form-control" id="Deskripsi_modul" name="Deskripsi_modul" placeholder="Deskripsi Modul"></textarea>
        </div>

        <div class="custom-file">
            <input type="file" class="custom-file-input" id="file_modul" name="file_modul">
            <label class="custom-file-label" for="image">pilih file</label>
        </div>


    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">tutup</button>
        <button type="submit" class="btn btn-primary">tambah</button>
    </div>
</form>