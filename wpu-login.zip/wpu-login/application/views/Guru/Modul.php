<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>


    <div class="row">
        <div class="col-lg">
            <a href="<?= base_url('Guru/tambahmodul'); ?>" class="btn btn-primary mb-3">Tambah Modul baru</a>
            <?= $this->session->flashdata('message'); ?>
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th scope="col">Nomor Modul</th>
                        <th scope="col">Nama Modul</th>
                        <th scope="col">Deskripsi</th>
                        <th scope="col">File Modul</th>
                        <th scope="col">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1; ?>
                    <?php foreach ($modul as $m) : ?>
                        <tr>
                            <th scope="row"><?= $i; ?></th>
                            <td><?= $m['nama_modul']; ?></td>
                            <td><?= $m['Deskripsi_modul']; ?></td>
                            <td><?= $m['file_modul']; ?></td>
                            <td>
                                <a href="<?= base_url('Guru/editmodul/' . $m['id_modul']); ?>" class="badge badge-success">Edit</a>
                                <a href="<?= base_url('Guru/deletemodul/' . $m['id_modul']); ?>" class="badge badge-danger">Hapus</a>

                            </td>
                        </tr>
                        <?php $i++; ?>
                    <?php endforeach; ?>
                </tbody>
            </table>



        </div>
    </div>

    <div class="modal fade" id="newmodulmodal" tabindex="-1" role="dialog" aria-labelledby="newmodulmodallabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="newmodulmodallabel">tambah Modul Baru</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->