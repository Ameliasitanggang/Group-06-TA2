<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Guru extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        is_logged_in();
        $this->load->model('pelajaran_model');
    }

    public function Modul()
    {
        $data['title'] = 'Kelola Modul';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['modul'] = $this->db->get('modul')->result_array();

        $this->form_validation->set_rules('name', 'Full Name', 'required|trim');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('Guru/Modul', $data);
            $this->load->view('templates/footer');
        } else {

            $data = [
                'id_modul' => $this->input->post('id_modul'),
                'nama_modul' => $this->input->post('nama_modul'),
                'Deskripsi_modul' => $this->input->post('Deskripsi_modul'),
                'waktu' => $this->input->post('waktu'),
                'file_modul' => $this->input->post('file_modul')
            ];
            $this->db->insert('modul', $data);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">modul ditambahkan!</div>');
            redirect('modul');
        }
    }



    public function tambahmodul()
    {
        $data['title'] = 'tambahmodul';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['modul'] = $this->db->get('modul')->result_array();


        $this->form_validation->set_rules('nama_modul', 'nama_modul', 'required|trim', [
            'required' => 'Masukkan nama modul!'
        ]);
        $this->form_validation->set_rules('Deskripsi_modul', 'Deskripsi_modul', 'required|trim', [
            'required' => 'Masukkan deskripsi modul!'
        ]);
        $this->form_validation->set_rules('file_modul', 'file_modul', 'required|trim', [
            'required' => 'Masukkan file modul!'
        ]);
        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('Guru/tambahmodul', $data);
            $this->load->view('templates/footer');
        } else {

            $data = [

                'nama_modul' => $this->input->post('nama_modul'),
                'Deskripsi_modul' => $this->input->post('Deskripsi_modul'),
                'file_modul' => $this->input->post('file_modul')
            ];
            $this->db->insert('modul', $data);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">modul berhasil ditambahkan!</div>');
            redirect('Guru/Modul');
        }
    }
    public function editmodul($id_modul)

    {
        $data['title'] = 'editmodul';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['modul'] = $this->pelajaran_model->detail($id_modul);
        $this->form_validation->set_rules('nama_modul', 'nama_modul', 'required|trim', ['required' => 'Masukkan nama modul!']);
        $this->form_validation->set_rules('Deskripsi_modul', 'Deskripsi_modul', 'required|trim', ['required' => 'Masukkan deskripsi modul!']);


        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('Guru/editmodul', $data);
            $this->load->view('templates/footer');
        } else {
            if ($this->form_validation->run() == true) {
                $i = $this->input;
                $data = array(
                    'id_modul'                 => $id_modul,
                    'nama_modul'               => $i->post('nama_modul'),
                    'Deskripsi_modul'          => $i->post('Deskripsi_modul'),
                    'file_modul'               => $i->post('file_modul'),
                );
                $this->pelajaran_model->edit($data);
                $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">modul berhasil diubah!</div>');
                redirect('Guru/Modul');
            } else {
                $i = $this->input;
                $data = array(
                    'id_modul'                 => $id_modul,
                    'nama_modul'               => $i->post('nama_modul'),
                    'Deskripsi_modul'          => $i->post('Deskripsi_modul'),
                );
                $this->pelajaran_model->edit($data);
                $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">modul berhasil diubah</div>');
                redirect('Guru/Modul');
            }
        }
    }


    public function deletemodul($m)
    {
        $this->db->where('id_modul', $m);
        $this->db->delete('modul');
        $this->session->set_flashdata('message', '
        <div class="alert alert-success" role="alert">
            Berhasil menghapus Data Modul!
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
            </button>
        </div>');
        redirect('Guru/Modul');
    }
}
