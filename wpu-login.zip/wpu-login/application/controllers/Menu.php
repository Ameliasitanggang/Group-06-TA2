<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Menu extends CI_Controller
{
    public function __construct()
    {

        parent::__construct();
        is_logged_in();
        $this->load->model('pengumuman_model');
    }

    public function index()
    {
        $data['title'] = 'Menu Management';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $data['menu'] = $this->db->get('user_menu')->result_array();

        $this->form_validation->set_rules('menu', 'Menu', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('menu/index', $data);
            $this->load->view('templates/footer');
        } else {
            $this->db->insert('user_menu', ['menu' => $this->input->post('menu')]);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">New menu added!</div>');
            redirect('menu');
        }
    }


    public function submenu()
    {
        $data['title'] = 'Submenu Management';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $this->load->model('Menu_model', 'menu');

        $data['subMenu'] = $this->menu->getSubMenu();
        $data['menu'] = $this->db->get('user_menu')->result_array();

        $this->form_validation->set_rules('title', 'Title', 'required');
        $this->form_validation->set_rules('menu_id', 'Menu', 'required');
        $this->form_validation->set_rules('url', 'URL', 'required');
        $this->form_validation->set_rules('icon', 'icon', 'required');

        if ($this->form_validation->run() ==  false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('menu/submenu', $data);
            $this->load->view('templates/footer');
        } else {
            $data = [
                'title' => $this->input->post('title'),
                'menu_id' => $this->input->post('menu_id'),
                'url' => $this->input->post('url'),
                'icon' => $this->input->post('icon'),
                'is_active' => $this->input->post('is_active')
            ];
            $this->db->insert('user_sub_menu', $data);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">New sub menu added!</div>');
            redirect('menu/submenu');
        }
    }

    public function Pengumuman()
    {
        $data['title'] = 'Pengumuman';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['pengumuman'] = $this->db->get('pengumuman')->result_array();

        $this->form_validation->set_rules('name', 'Full Name', 'required|trim');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('Menu/Pengumuman', $data);
            $this->load->view('templates/footer');
        } else {

            $data = [
                'id_pengumuman' => $this->input->post('id_pengumuman'),
                'nama_pengumuman' => $this->input->post('nama_pengumuman'),
                'deskripsi' => $this->input->post('deskripsi'),
                'waktu' => $this->input->post('waktu'),
                'file_pengumuman' => $this->input->post('file_pengumuman')
            ];
            $this->db->insert('pengumuman', $data);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">pengumuman ditambahkan!</div>');
            redirect('pengumuman');
        }
    }

    public function TambahPengumuman()
    {
        $data['title'] = 'TambahPengumuman';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['pengumuman'] = $this->db->get('pengumuman')->result_array();

        $this->form_validation->set_rules('nama_pengumuman', 'nama_pengumuman', 'required|trim', [
            'required' => 'Masukkan nama Pengumuman!'
        ]);
        $this->form_validation->set_rules('deskripsi', 'deskripsi', 'required|trim', [
            'required' => 'Masukkan deskripsi Pengumuman!'
        ]);
        $this->form_validation->set_rules('file_pengumuman', 'file_pengumuman', 'required|trim', [
            'required' => 'Masukkan file Pengumuman!'
        ]);
        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('Menu/TambahPengumuman', $data);
            $this->load->view('templates/footer');
        } else {

            $data = [

                'nama_pengumuman' => $this->input->post('nama_pengumuman'),
                'deskripsi' => $this->input->post('deskripsi'),
                'file_pengumuman' => $this->input->post('file_pengumuman')
            ];
            $this->db->insert('pengumuman', $data);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">pengumuman ditambahkan!</div>');
            redirect('menu/pengumuman');
        }
    }

    public function editpengumuman($id_pengumuman)

    {
        $data['title'] = 'edit pengumuman';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['pengumuman'] = $this->pengumuman_model->detail($id_pengumuman);
        $this->form_validation->set_rules('nama_pengumuman', 'nama_pengumuman', 'required|trim', ['required' => 'Masukkan nama Pengumuman!']);
        $this->form_validation->set_rules('deskripsi', 'deskripsi', 'required|trim', ['required' => 'Masukkan deskripsi Pengumuman!']);

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('Menu/editpengumuman', $data);
            $this->load->view('templates/footer');
        } else {
            if ($this->form_validation->run() == true) {
                $i = $this->input;
                $data = array(
                    'id_pengumuman'                 => $id_pengumuman,
                    'nama_pengumuman'               => $i->post('nama_pengumuman'),
                    'deskripsi'                     => $i->post('deskripsi'),
                    'file_pengumuman'               => $i->post('file_pengumuman'),
                );
                $this->pengumuman_model->edit($data);
                $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">pengumuman sudah berubah!</div>');
                redirect('menu/pengumuman');
            } else {
                $i = $this->input;
                $data = array(
                    'id_pengumuman'                 => $id_pengumuman,
                    'nama_pengumuman'               => $i->post('nama_pengumuman'),
                    'deskripsi'                     => $i->post('deskripsi'),
                );
                $this->pengumuman_model->edit($data);
                $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">pengumuman sudah berubah!</div>');
                redirect('menu/pengumuman');
            }
        }
    }
    public function deletepengumuman($m)
    {
        $this->db->where('id_pengumuman', $m);
        $this->db->delete('pengumuman');
        $this->session->set_flashdata('message', '
        <div class="alert alert-danger" role="alert">
            Berhasil menghapus Data Pengumuman!
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
            </button>
        </div>');
        redirect('Menu/Pengumuman');
    }
}
