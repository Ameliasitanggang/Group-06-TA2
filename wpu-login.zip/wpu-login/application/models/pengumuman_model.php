<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Pengumuman_model extends CI_Model
{
    public function detail($id_pengumuman)
    {
        $this->db->select('*');
        $this->db->from('pengumuman');
        $this->db->where('id_pengumuman', $id_pengumuman);
        $this->db->order_by('id_pengumuman', 'ASC');
        $query = $this->db->get();
        return $query->row();
    }

    public function edit($data)
    {
        $this->db->where('id_pengumuman', $data['id_pengumuman']);
        $this->db->update('pengumuman', $data);
    }
}
