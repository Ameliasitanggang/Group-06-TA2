<?php
defined('BASEPATH') or exit('No direct script access allowed');

class pelajaran_model extends CI_Model
{
    public function detail($id_modul)
    {
        $this->db->select('*');
        $this->db->from('modul');
        $this->db->where('id_modul', $id_modul);
        $this->db->order_by('id_modul', 'ASC');
        $query = $this->db->get();
        return $query->row();
    }

    public function edit($data)
    {
        $this->db->where('id_modul', $data['id_modul']);
        $this->db->update('modul', $data);
    }
}
